from flask import Flask, render_template, request
from stegano import lsb

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html', message=None)  # Pass None for message initially

@app.route('/hide', methods=['POST'])
def hide_message():
    message = request.form['message']
    file = request.files['file']
    if file.filename != '':
        file_path = 'uploads/' + file.filename
        file.save(file_path)
        secret = lsb.hide(file_path, message)
        secret.save(file_path)  # Overwrite the original file with the one containing the hidden message
        return render_template('index.html', message='Message hidden successfully!')
    return render_template('index.html', message='No file selected.')

@app.route('/retrieve', methods=['POST'])
def retrieve_message():
    file = request.files['file']
    if file.filename != '':
        file_path = 'uploads/' + file.filename
        try:
            message = lsb.reveal(file_path)
            return render_template('index.html', message=message)
        except Exception as e:
            return render_template('index.html', message='Error: ' + str(e))
    return render_template('index.html', message='No file selected.')

if __name__ == '__main__':
    app.run(debug=True)
